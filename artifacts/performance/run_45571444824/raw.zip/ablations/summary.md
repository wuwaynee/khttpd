# Matched performance measurements

Source commit: 0bfbe252a283102e5638b9004d5ece366e40a2f9
Kernel: Linux ip-10-0-129-120 7.0.0-1014-aws #14~24.04.1-Ubuntu SMP PREEMPT Fri Sep 18 21:24:59 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux

Each cell: 3 runs, 10 seconds, wrk 4T/256C.
Primary measurement is plain wrk; a separate same-load phase validates every response.
Values below are medians across runs, not pooled percentiles.

| Profile | req/s | p50 ms | p99 ms | socket error events | min–max req/s |
|---|---:|---:|---:|---:|---:|
| hardened_alloc | 393934.19 | 0.323 | 0.601 | 0 | 340364.36–398275.79 |
| hardened_close | 88945.52 | 0.500 | 1.400 | 0 | 86711.05–89076.24 |
| legacy_optimized1 | 403587.15 | 0.323 | 0.547 | 0 | 352390.18–405793.25 |
| legacy_no_pool | 401528.10 | 0.320 | 0.549 | 0 | 364933.02–405064.07 |
| hardened1 | 382702.02 | 0.332 | 0.680 | 0 | 373381.39–387445.50 |
| keepalive_logged512 | 191262.02 | 0.409 | 43.260 | 0 | 181978.48–197307.77 |
| close_no_logging | 14440.71 | 2.550 | 525.250 | 16 | 14435.43–14516.68 |
| keepalive_quiet512 | 369715.91 | 0.336 | 0.749 | 0 | 354098.21–389829.44 |

Ratios use the matched_close512 control in the same repetition.


historical_close112 preserves the valid 112-byte close/log/clear/single-listener behavior from source 3fbe63b. It matches the recorded old response-size shape.
matched_close512 raises its backlog to the optimized value to avoid attributing simple accept-queue capacity to the remaining optimizations. It is the conservative primary control.
Socket error events are reported, never omitted; latency percentiles are for completed requests. Server close-phase I/O counters can include peers terminating in-flight work after wrk stops and are not equivalent to load-generator errors.
These are measurements on the recorded hosted VM. They do not retroactively establish the exact hardware/configuration of the 2025 logs.
