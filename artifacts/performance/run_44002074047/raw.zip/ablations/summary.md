# Matched performance measurements

Source commit: c1dda1ae93c1deb3cf2cc258051a7113f13a0094
Kernel: Linux runnervm8axu0 7.0.0-1017-azure #17~24.04.1-Ubuntu SMP PREEMPT Thu Sep 24 18:46:57 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux

Each cell: 3 runs, 10 seconds, wrk 4T/256C.
Primary measurement is plain wrk; a separate same-load phase validates every response.
Values below are medians across runs, not pooled percentiles.

| Profile | req/s | p50 ms | p99 ms | socket error events | min–max req/s |
|---|---:|---:|---:|---:|---:|
| hardened_alloc | 176828.25 | 0.721 | 1.320 | 0 | 176539.57–177039.44 |
| hardened_close | 39011.82 | 1.150 | 3.360 | 0 | 38949.30–39643.87 |
| legacy_optimized1 | 178062.55 | 0.726 | 1.270 | 0 | 177717.59–179031.49 |
| legacy_no_pool | 176962.54 | 0.730 | 1.270 | 0 | 176857.51–179766.22 |
| hardened1 | 177372.06 | 0.724 | 1.300 | 0 | 176555.31–177546.30 |
| keepalive_logged512 | 92037.36 | 0.950 | 35.960 | 0 | 90424.34–93589.69 |
| close_no_logging | 13892.14 | 5.370 | 214.790 | 11 | 13782.72–13927.77 |
| keepalive_quiet512 | 176582.18 | 0.733 | 1.280 | 0 | 172469.56–176747.47 |

Ratios use the matched_close512 control in the same repetition.


historical_close112 preserves the valid 112-byte close/log/clear/single-listener behavior from source 3fbe63b. It matches the recorded old response-size shape.
matched_close512 raises its backlog to the optimized value to avoid attributing simple accept-queue capacity to the remaining optimizations. It is the conservative primary control.
Socket error events are reported, never omitted; latency percentiles are for completed requests. Server close-phase I/O counters can include peers terminating in-flight work after wrk stops and are not equivalent to load-generator errors.
These are measurements on the recorded hosted VM. They do not retroactively establish the exact hardware/configuration of the 2025 logs.
